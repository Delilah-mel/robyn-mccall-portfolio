# Robyn McCall Portfolio

A responsive single-page portfolio for fictional creative professional Robyn McCall.

## Local development

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
```

The generated `dist/` directory can be deployed to Cloudflare Pages as a static site. The contact form is intentionally a visual demo and does not deliver messages until a form service or backend is connected.
